## KediRNG

### A basic web based chance game.

- Designed by OBX555
- Programmed, styled and produced by tyuXX