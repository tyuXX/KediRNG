var raritiesDone = defRaritiesDone;
var combinationsDone = [];
var inventory = defInventory;
var money = new Decimal(0);
var quests = [];
