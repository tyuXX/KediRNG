var raritiesDone = defRaritiesDone;
var combinationsDone = [];
var inventory = defInventory;
var money = 0;
var quests = [];
